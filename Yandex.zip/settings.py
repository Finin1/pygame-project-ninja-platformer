import pygame

pygame.init()


pygame.display.set_caption('Ninja: "Hurricane Chronicles"')
clock = pygame.time.Clock()
font_type = pygame.font.SysFont('arial', 36)  # шрифт
fps = 60
name_file_stat = 'data/stat.json'
